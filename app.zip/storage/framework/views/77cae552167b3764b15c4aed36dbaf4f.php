<?php if($type=='password'): ?>
    <label class="form-label" for="<?php echo e($name); ?>"><?php echo e($title); ?> <?php if($required=="True"): ?><span style="color:red;"> *</span><?php endif; ?></label>
    <input id="<?php echo e($id); ?>" type="<?php echo e($type); ?>" class="<?php echo e($class); ?>" name="<?php echo e($name); ?>" value="<?php echo e(old($name)); ?>" placeholder="<?php echo e($title); ?>" <?php if($required=="True"): ?> required <?php endif; ?> autocomplete="<?php echo e($name); ?>" autofocus>
    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="error mt-2 text-danger" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<?php elseif($type=='textarea'): ?>
    <div class="form-group">
        <label class="form-label" for="<?php echo e($name); ?>"><?php echo e($title); ?> <?php if($required=="True"): ?><span style="color:red;"> *</span><?php endif; ?></label>
        <textarea id="<?php echo e($id); ?>" cols="30" rows="5" class="<?php echo e($class); ?>" name="<?php echo e($name); ?>" value="<?php echo e(old($name)); ?>" placeholder="<?php echo e($title); ?>" <?php if($required=="True"): ?> required <?php endif; ?> autocomplete="<?php echo e($name); ?>" autofocus></textarea>
        <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="error mt-2 text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
<?php elseif($type=='number'): ?>
    <label class="form-label" for="<?php echo e($name); ?>"><?php echo e($title); ?> <?php if($required=="True"): ?><span style="color:red;"> *</span><?php endif; ?></label>
    <input id="<?php echo e($id); ?>" type="<?php echo e($type); ?>" class="<?php echo e($class); ?>" name="<?php echo e($name); ?>" value="<?php echo e(old($name)); ?>" placeholder="<?php echo e($title); ?>" <?php if($required=="True"): ?> required <?php endif; ?> autocomplete="<?php echo e($name); ?>" autofocus>
    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="error mt-2 text-danger" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<?php elseif($type=='file'): ?>
    <label class="form-label" for="<?php echo e($name); ?>"><?php echo e($title); ?> <?php if($required=="True"): ?><span style="color:red;"> *</span><?php endif; ?></label>
    <div class="input-group">
        <div class="custom-file">
            <input type="file" class="<?php echo e($class); ?>" id="<?php echo e($id); ?>" name="<?php echo e($name); ?>"  <?php if($required=="True"): ?> required <?php endif; ?> style="width:100% !important;">
        </div>
    </div>
    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="error mt-2 text-danger" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<?php elseif($type=='date'): ?>
    <label class="form-label" for="<?php echo e($name); ?>"><?php echo e($title); ?> <?php if($required=="True"): ?><span style="color:red;"> *</span><?php endif; ?></label>
    <div class="input-group date" id="<?php echo e($id); ?>" data-target-input="nearest">
        <input type="text" class="datetimepicker-input <?php echo e($class); ?>" data-target="#<?php echo e($id); ?>" name="<?php echo e($name); ?>"  <?php if($required=="True"): ?> required <?php endif; ?>>
        <div class="input-group-append" data-target="#<?php echo e($id); ?>" data-toggle="datetimepicker" placeholder="<?php echo e($title); ?>">
            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
        </div>
    </div>
    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="error mt-2 text-danger" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<?php else: ?>
    <label class="form-label" for="<?php echo e($name); ?>"><?php echo e($title); ?> <?php if($required=="True"): ?><span style="color:red;"> *</span><?php endif; ?></label>
    <input id="<?php echo e($id); ?>" type="<?php echo e($type); ?>" class="<?php echo e($class); ?>" name="<?php echo e($name); ?>" value="<?php echo e(old($name)); ?>" placeholder="<?php echo e($title); ?>" <?php if($required=="True"): ?> required <?php endif; ?> autocomplete="<?php echo e($name); ?>" autofocus>
    <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="error mt-2 text-danger" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<?php endif; ?><?php /**PATH G:\Laravel Projects\Wergex\ats\resources\views/components/forms/input.blade.php ENDPATH**/ ?>